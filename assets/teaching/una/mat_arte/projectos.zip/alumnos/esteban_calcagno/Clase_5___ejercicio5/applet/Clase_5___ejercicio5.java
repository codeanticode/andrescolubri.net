import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.*; 
import java.awt.image.*; 
import java.awt.event.*; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Clase_5___ejercicio5 extends PApplet {

float t = 0.0f;
float t2 = 0.0f;
float t3 = 0.0f;
public void setup()
{
size(400,400);
background(255);
smooth();
}

public void draw() {
 
  fill(t%255, t2%255, 0, 10);
  rect(0, 0, width, height);
  
  //ELIPSE TRAYECTORIA PARABOLICA
  fill(255, 0,0);
  ellipse((t%400), (t%400)*(t%400)*0.0025f, 10, 10);
 
  //ELIPSE TRAYECTORIA LINEAL
  fill(0, 255, 0);
  ellipse((t%400), (t%400), 10, 10);
 
  //ELIPSE TRAYECTORIA SENOIDAL
  fill(255, 255, 0);  
  ellipse((t2%400), sin((t2%400))*200 + 200, t3%30,t3%30);
  
  //TRIANGULO DONDE LAS TRAYECTORIAS DE ALGUNAS DE LAS COORDENADAS DE SUS PUNTOS RESPONDEN A UNA FUNCION LOGARITMICA
  fill(0, 0, 255);  
  triangle((t%400)+30, 20*log(t%400)+75, (t%400)+58, (t%400)+20, (t%400)+86, (t%400)+75);

  //LINEA QUE UNE ELIPSE TRAYECTORIA LINEAL CON ELIPSE TRAYECTORIA SENOIDAL 
  line((t%400), (t%400), (t2%400), sin((t2%400))*200 + 200);
  
  //LINEA QUE UNE ELIPSE TRAYECTORIA PARABOLA CON ELIPSE TRAYECTORIA LINEAL
  line((t%400), (t%400)*(t%400)*0.0025f,  (t%400), (t%400));
  
  //LINEA QUE UNE ELIPSE TRAYECTORIA PARABOLA CON ELIPSE TRAYECTORIA SENOIDAL
  line((t%400), (t%400)*(t%400)*0.0025f,  (t2%400), sin((t2%400))*200 + 200);
  
  //LINEAS ENTRE EL ORIGEN Y LOS TRES PUNTOS DEL TRIANGULO 
  line(0, 0,   (t%400)+30, 20*log(t%400)+75);
  line(0, 0,   (t%400)+58, (t%400)+20);
  line(0, 0,   (t%400)+86, (t%400)+75);
  
  //LINEAS ENTRE LA ELIPSE TRAYECTORIA LINEAL Y LOS TRES PUNTOS DEL TRIANGULO 
  line((t%400), (t%400),   (t%400)+30, 20*log(t%400)+75);
  line((t%400), (t%400),   (t%400)+58, (t%400)+20);
  line((t%400), (t%400),   (t%400)+86, (t%400)+75);

  //LINEAS ENTRE LA ELIPSE TRAYECTORIA PARABOLICA Y LOS TRES PUNTOS DEL TRIANGULO 
  line((t%400), (t%400)*(t%400)*0.0025f,   (t%400)+30, 20*log(t%400)+75);
  line((t%400), (t%400)*(t%400)*0.0025f,   (t%400)+58, (t%400)+20);
  line((t%400), (t%400)*(t%400)*0.0025f,   (t%400)+86, (t%400)+75);
  
  //LINEAS ENTRE LA ELIPSE TRAYECTORIA SENOIDAL Y LOS TRES PUNTOS DEL TRIANGULO 
  line((t2%400), sin((t2%400))*200 + 200,   (t%400)+30, 20*log(t%400)+75);
  line((t2%400), sin((t2%400))*200 + 200,   (t%400)+58, (t%400)+20);
  line((t2%400), sin((t2%400))*200 + 200,   (t%400)+86, (t%400)+75);
  
  t += 1.0f;  
  t2 += 0.1f;
  t3 += 0.1f;
}


  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#DFDFDF", "Clase_5___ejercicio5" });
  }
}
